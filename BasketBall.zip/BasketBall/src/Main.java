import config.DBConfig;
import model.BasketBaller;
import repo.BasketBallerRepository;
import javax.swing.*;
import java.sql.SQLException;
public class Main {
    public static void main(String[] args) {
        menu();
    }
    public static void menu() {
        BasketBallerRepository repo = new BasketBallerRepository();
        int response = 0;

        while (response != 5) {
            try {
                String option = JOptionPane.showInputDialog(
                        "Introduce an option: \n" +
                                "1- Insert BasketBaller \n" +
                                "2- Update BasketBaller \n" +
                                "3- Delete BasketBaller by ID \n" +
                                "4- Read All BasketBallers \n" +
                                "5- Exit"
                );
                response = Integer.parseInt(option);

                switch (response) {
                    case 1:
                        // Insert BasketBaller
                        String name = JOptionPane.showInputDialog("Enter BasketBaller's name:");
                        String team = JOptionPane.showInputDialog("Enter BasketBaller's team:");
                        int number = Integer.parseInt(JOptionPane.showInputDialog("Enter BasketBaller's number:"));
                        double height = Double.parseDouble(JOptionPane.showInputDialog("Enter BasketBaller's height:"));

                        BasketBaller basketBaller = new BasketBaller(0, name, team, number, height);
                        repo.insertBasketBaller(basketBaller);
                        JOptionPane.showMessageDialog(null, "Inserted BasketBaller: " + basketBaller.toString());
                        break;
                    case 2:
                        // Update BasketBaller
                        int updateId = Integer.parseInt(JOptionPane.showInputDialog("Enter BasketBaller's ID to update:"));
                        basketBaller = repo.getBasketBallerById(updateId).orElse(null);

                        if (basketBaller != null) {
                            String newTeam = JOptionPane.showInputDialog("Enter BasketBaller's new team:");
                            basketBaller.setEquipo(newTeam);
                            JOptionPane.showMessageDialog(null, "Updated BasketBaller: " + repo.updateBasketBaller(basketBaller));
                        } else {
                            JOptionPane.showMessageDialog(null, "BasketBaller with ID " + updateId + " not found.");
                        }
                        break;
                    case 3:
                        // Delete BasketBaller by ID
                        int deleteId = Integer.parseInt(JOptionPane.showInputDialog("Enter BasketBaller's ID to delete:"));
                        repo.deleteBasketBallerById(deleteId);
                        JOptionPane.showMessageDialog(null, "Deleted BasketBaller with ID: " + deleteId);
                        break;
                    case 4:
                        // Read All BasketBallers
                        JOptionPane.showMessageDialog(null, "All BasketBallers: \n" + repo.readAllBasketBaller());
                        break;
                    case 5:
                        // Exit
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
            }
        }
    }
}
