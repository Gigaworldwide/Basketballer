package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DBConfig {

    private DBConfig() {

    }

    public static Connection openConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:derby://localhost:1527/BasketBallDb;create=true");
    }

    public static void createTableQuery() {
        String createTableQuery = """
                CREATE TABLE BasketBaller (
                   Id INT NOT NULL GENERATED ALWAYS AS IDENTITY,
                   NOMBRE VARCHAR(255),
                   EQUIPO VARCHAR(255),
                   NUMERO INT NOT NULL,
                   ALTURA NUMERIC(5,2),
                   PRIMARY KEY (Id)
                )
                """;
        try {
            openConnection().createStatement().execute(createTableQuery);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
