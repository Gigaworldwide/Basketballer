package model;

public class BasketBaller {
    private int id;
    private String nombre;
    private String equipo;
    private int numero;
    private double altura;


    public BasketBaller(int id, String nombre, String equipo, int numero, double altura) {
        this.id = id;
        this.nombre = nombre;
        this.equipo = equipo;
        this.numero = numero;
        this.altura = altura;
    }

    public BasketBaller(int id) {
        this.id = id;
    }

    public BasketBaller() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return "BasketBaller{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", equipo='" + equipo + '\'' +
                ", numero=" + numero +
                ", altura=" + altura +
                '}';
    }
}
