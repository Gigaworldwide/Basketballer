package repo;

import config.DBConfig;
import model.BasketBaller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

public class BasketBallerRepository {
    private final String tableName = "BasketBaller";

    public ArrayList<BasketBaller> readAllBasketBaller() {
        ArrayList<BasketBaller> basketBallers = new ArrayList<>();
        try (Connection connection = DBConfig.openConnection()) {
            ResultSet resultSet = connection
                    .createStatement()
                    .executeQuery("select ID, NOMBRE,  EQUIPO,  NUMERO, ALTURA from BasketBaller ");
            while (resultSet.next()) {
                basketBallers.add(resultSetToBasketBaller(resultSet));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return basketBallers;
    }


    public int insertBasketBaller(BasketBaller basketBaller) {
        try (Connection connection = DBConfig.openConnection()) {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("insert into BasketBaller ( NOMBRE,  EQUIPO,  NUMERO, ALTURA) values (?,?,?,?)");
            preparedStatement.setString(1, basketBaller.getNombre());
            preparedStatement.setString(2, basketBaller.getEquipo());
            preparedStatement.setInt(3, basketBaller.getNumero());
            preparedStatement.setDouble(4, basketBaller.getAltura());

            return preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Optional<BasketBaller> getBasketBallerById(int id) {
        try (Connection connection = DBConfig.openConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement("select ID, NOMBRE,  EQUIPO,  NUMERO, ALTURA from BasketBaller where ID=?");
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return Optional.of(resultSetToBasketBaller(resultSet));
            }
            return Optional.empty();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Optional<BasketBaller> updateBasketBaller(BasketBaller basketBaller) {
        int id = basketBaller.getId();
        String sql = """
                update BasketBaller
                set NOMBRE = ?,  
                EQUIPO = ?,  
                NUMERO = ?, 
                ALTURA = ?
                WHERE ID = ?
                """;
        try (Connection connection = DBConfig.openConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, basketBaller.getNombre());
            preparedStatement.setString(2, basketBaller.getEquipo());
            preparedStatement.setInt(3, basketBaller.getNumero());
            preparedStatement.setDouble(4, basketBaller.getAltura());
            preparedStatement.setInt(5, id);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return getBasketBallerById(id);
    }
    public void deleteBasketBallerById(int id) {
        try (Connection connection = DBConfig.openConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement("delete from BasketBaller where ID=?");
            preparedStatement.setInt(1, id);
             preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    private BasketBaller resultSetToBasketBaller(ResultSet resultSet) throws SQLException {
        return new BasketBaller(
                resultSet.getInt("ID"),
                resultSet.getString("NOMBRE"),
                resultSet.getString("EQUIPO"),
                resultSet.getInt("NUMERO"),
                resultSet.getDouble("ALTURA")
        );
    }

}
